#Enunciado
#Crear estas clases : Tres archivos diferentes
#Define los atributos, métodos, constructores... que consideres necesarios.
#atributos los tendremos en el constructor


#cursos:id,nombre, creditos, añosdeestudio - entidad - modelo - dataClass
#alumno:id, nombre, email
#matricula:idmatricula, fechamatricula, idalumno, idcurso : tabla de pedidos. tabla relaciional

#matricula1=Matricula(1,'01/03/2022',5,7)
#matricula1=Matricula(1,'01/03/2022',alumno1,curso1)
#matricula2=Matricula(2,'25/03/2022',alumno1,[curso1,curso2])
#Necesitamos.
#mostrar la ficha del curso - método de la curso
#mostrar la ficha de alumno - método de la alumno
#alumno1 se matricula en un curso
#alumno2 se matricula en dos cursos : dos instancias
#mostrar los datos de matrícula - método de la clase matricula
#reto*:método que muestra las mátriculas realizadas en mi centro

print('Ejercicio de POO')