import pandas as pd
from xml_marshaller import xml_marshaller
class Cliente:
    def __init__(self, nombre, ciudad, facturacion):
        self.nombre=nombre
        self.ciudad=ciudad
        self.facturacion=facturacion
cliente=Cliente('a','bb','ccc')

