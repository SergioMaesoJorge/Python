# • Diseña una aplicación que pida por consola una ciudad de destino. Si introduces un 0 y
# pulsas intro, sales de la aplicación. (5 puntos).
# • Si introduces madrid, sevilla o valencia, te permite continuar y te pregunta cuántas
# noches de hotel necesitas. Es indiferente que escribas las ciudades en mayúsculas o
# minúsculas.. (10 puntos)
# • Al escribir las noches de hotel te muestra un error si no introduces un número. (5
# puntos)
# • Una vez finalizado, te muestra un mensaje indicando la ciudad y las noches de hotel
# que has introducido. (5 puntos)

def actividad1(): #Creamos una función que podemos invocar en cualquier momento
    ciudad=input('Dime una ciudad de destino, introduce 0 para finalizar el programa: ') #Necesitamos que el programa pida una ciudad
    noches=0 #Declaramos la variable noches. Vamos a usarla más tarde.
    while ciudad != '0': #Un bucle while que funciona mientras no se introduzca un 0 por consola
        ciudad=ciudad.lower() #Necesitamos convertir las ciudades introducidas a cadenas en minúsculas
        #Esto facilita el trabajo y evita errores si el usuario introduce letras mayúsculas
        if ciudad=='madrid' or ciudad=='valencia' or ciudad =='sevilla': #Estructura condicional
        #Detecta si la ciudad introducida es una de las que tenemos que preguntar cuántas noches vamos a quedarnos en un hotel
            try: #Usamos la estructura try para controlar errores que nos podemos encontrar
            #Por ejemplo, un error que puede cometer el usuario es introducir un número no entero o una cadena de caracteres
                noches=int(input('Dime cuántas noches de hotel necesitas: ')) #Preguntamos cuántas noches se va a quedar el usuario
            except: #Si hay algún error al pedir las noches, por consola se muestra un mensaje predeterminado
                print('Lo sentimos, no ha introducido un número.')
            finally: #Al terminar la secuencia salimos del bucle. Esto se ejecuta siempre, haya errores o no
                break
        ciudad = input('¿Quiere probar otra ciudad?, introduce 0 para finalizar el programa: ')
        #En caso de que la ciudad que pedimos no es una de las que pedimos noches de hotel, pedimos otra
    print(f'Vas a quedarte en la ciudad {ciudad} y vas a estar {noches} noches de hotel.')
    #Finalmente imprimimos por pntalla la ciudad y cuántas noches se va a quedar el usuario
actividad1() #Invocamos a la función para poder usarla