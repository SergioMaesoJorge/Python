# Actividad 2 Python – POO (25 puntos)
# • Diseña las clases Rectangulo, Cuadrado y Pentágono. Estas clases tienen el nombre del
# polígono y su número de lados. Realizamos el ejercicio en Python (10 puntos)
# • Diseña una aplicación por consola que nos permita introducir el nombre y la longitud
# para cada tipo de polígono. Te mostrará el nombre y el área del poligono elegio. (10
# puntos)
# • Utilizas POO y en concreto herencia (5 puntos)

def actividad2():
    class Poligono: #Creamos la clase Polígono
        def __init__(self): #Declaración del constructor
            self.nombre=input('Dime el nombre de tu polígono: ') #Pedimos el nombre del polígono
            self.lados=int(input('Dime cuántos lados tiene tu polígono: ')) #Pedimos los lados del polígono
        def mostrarNombre(self):
            print(f'El nombre del polígono es {self.nombre}') #Mostramos el nombre del polígono
    class Rectangulo(Poligono):
        @staticmethod
        def caracteristicas(): #Explicar las características de un rectángulo
            print('Un rectángulo tiene 4 lados')
        def mostrarArea(self): #Mostrar el área del rectángulo
            base = float(input('Dime cuánto mide la base: ')) #Pedimos base
            altura= float(input('Dime cuánto mide la altura: ')) #Pedimos altura
            print(f'El área es {base*altura}') #Mostramos el área
    class Cuadrado(Poligono): #Clase Cuadrado
        @staticmethod
        def caracteristicas(): #Características de un cuadrado
            print('Un cuadrado tiene 4 lados')
        def mostrarArea(self):
            lado = float(input('Dime cuánto mide cada lado: ')) #Pedimos el lado de un cuadrado
            print(f'El área es {lado*lado}') #Mostramos el área
    class Pentagono(Poligono): #clase Polígono
        @staticmethod
        def caracteristicas(): #Mostramos las características de un pentágono
            print('Un pentágono tiene 5 lados')
        def mostrarArea(self):
            base = float(input('Dime cuánto mide la base: ')) #Pedimos la base
            altura= float(input('Dime cuánto mide la altura: ')) #Pedimos la altura
            print(f'El área de un pentágono es {base*altura} multiplicado por la apotema y dividido entre 2') #Calculamos el área
    poligono1=Poligono()
    poligono1.mostrarNombre()

actividad2()