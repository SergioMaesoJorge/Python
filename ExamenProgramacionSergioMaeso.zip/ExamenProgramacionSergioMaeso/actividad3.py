# • Crea una colección en donde introduces 4 ciudades y madrid.. Debes valorar y explicar
# brevemente qué tipo de colección vas a utilizar en este caso. Las ciudades se
# mostrarán ordenadas alfabéticamente. (10 puntos)
# • Añade una ciudad al final del listado de ciudades anterior. Y elimina madrid (5 puntos)
# • Muestra las ciudades en mayúsculas y el número de letras que la forman. (5 puntos)
# • Para todas las ciudades reemplaza las a por la e (5 puntos).


def actividad3():
    #Para esta actividad he elegido utilizar una lista porque es un conjunto ordenado y no se especifica que no se permita la repetición de elementos
    #Además permite la ordenación de elementos de forma alfabética con funciones como sort que con otros tipos de colecciones no se pueden usar

    coleccion= ['Madrid','Sevilla','Valencia','Barcelona','Getafe'] #Creación de nuestra colección con diferentes ciudades
    coleccion.sort()  #Ordenamos alfabéticamente las ciudades y las escribimos por pantalla
    print(f'La lista ordenada alfabéticamente: {coleccion}')
    coleccion.append('Badajoz') #Añadimos otra ciudad, en nuestro caso Badajoz
    coleccion.remove('Madrid') #Eliminamos Madrid de la lista
    print(f'La lista eliminando Madrid y añadiendo otra ciudad: {coleccion}') #Escribimos por pantalla
    for c in coleccion: #Para recorrer la lista elemento por elemento necesitamos un bucle for
        print(f'El nombre de la ciudad es {c.upper()} y el número de letras es {len(c)}')
        #Imprimimos por pantalla el nombre de la ciudad en mayúsculas y el número de letras que contiene
        print(f'El nombre de la ciudad con las letras cambiadas es {c.replace("a","e")}')
        #Imprimimos por pantalla el nombre de la ciudad cambiando "a" por "e"


actividad3()