#  Se inicia la aplicación y se genera un número aletario entre el 1 y el 9 (5 puntos)
#  La aplicación nos pide que adivinemos este número aleatorio. Seguirá mostrando
# el mensaje hasta que hayamos adivinado el número (5 puntos)
#  Muestra el total de intentos que has necesitado para adivinar el número. Si has
# necesitado más de 3 muestra un mensaje indicando que prueba no superada (5
# puntos)
#  No puedes repetir un número que ya hayas indicado (5 puntos)
#  Muestra cuánto tiempo tarda el programa en ejecutarse desde su inicio hasta que
# muestra el mensaje final que el número ha sido adivinado (5 puntos)
from datetime import datetime
from random import randint
#Necesitamos importar datetime y randint para poder usarlos en nuestro programa

def actividad4():
    fecha_inicio=datetime.now() #Guardamos en la variable fecha_inicio la fecha en la que empieza la prueba
    print(f'La hora de inicio es: {fecha_inicio.strftime("%H:%M:%S")}') #Usamos la función strftime para formatear la fecha
    #De esta forma podemos mostrar solo horas, minutos y segundos
    numero_aleatorio= randint(1,9) #Generamos un número aleatorio que guardamos en la variable numero_aleatorio
    adivinar=0 #Esta variable la vamos a utilizar para introducir números por pantalla
    contador=0 #Vriable contador para llevar la cuenta de los intentos necesitados
    numeros_usados=[] #Declaramos una lista en la que guardamos los números que vamos utilizando
    while adivinar != numero_aleatorio: #Bucle que se ejecuta mientras no adivinemos el número
        contador=contador+1 #Se suma 1 al contador cada vez que intentamos adivinar un número
        adivinar = int(input('Adivina un numero del 1 al 9: ')) #introducimos un número por consola
        for n in numeros_usados: #Bucle for que recorre la lista de números usados
            if adivinar == n: #Si hemos repetido el número
                print('Ya ha usado ese número, prueba otro') #Escribimos por consola que ya se ha usado ese número
                numeros_usados.remove(adivinar) #Y lo quitamos de la lista para evitar repetición
        numeros_usados.append(adivinar) #Añadimos el número a la lista
        if contador >= 3: #Cuando el contador llega a 3 intentos
            print('Prueba no superada') #Hemos fallado la prueba
            break #Y salimos del bucle
        if adivinar== numero_aleatorio: #Si adivinamos el número
            print('Felicidades, has superado la prueba y has adivinado el número ') #Felicitamos al usuario por superar la prueba
    print(f'Los números que has usado son: {numeros_usados}') #Escribimos por consola los números que el usuario ha introducido por pantalla
    fecha_fin = datetime.now() #Guardamos la fecha en la que termina la prueba
    print(f'La hora de final de ejecución es: {fecha_fin.strftime("%H:%M:%S")}') #Y la escribimos por pantalla
    #Solo se muestran horas, minutos y segundos con la función strftime.


actividad4()