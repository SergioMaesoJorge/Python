def pedir():
    pedirlista=int(input('introduce 1 para listas,2 para tuplas, 3 para sets y 4 para diccionarios: '))
    while pedirlista >= 5 or pedirlista <=0:
        pedirlista = int(input('introduce 1 para listas,2 para tuplas, 3 para sets y 4 para diccionarios'))
    if pedirlista == 1:
        print('Una lista es un conjunto ordenado de elementos')
    if pedirlista == 2:
        print('Una tupla es un conjunto ordenado de elementos que no admite cambios')
    if pedirlista ==3:
        print('Un set es un conjunto desordenado de elementos que no admite repetición')
    if pedirlista ==4:
        print('Un diccionario es un conjunto de datos con sus valores')
#pedir()

lista=[10, 'juan' , 9.95 , False , "madrid" , 15] #No hay ningún error porque Python admite diferentes tipos de datos en una lista
print(lista)
lista.append(25.95) #Se puede añadir porque es una lista. En una tupla esto no es posible
print(lista)

tupla=(10, 'juan' , 9.95 , False , "madrid" , 15) #No hay ningún error porque Python admite diferentes tipos de datos en una lista
print(tupla)
# No se pueden añadir elementos en una tupla
# lista.sort() #No se pueden ordenar diferentes tipos de datos
# print(lista)
# tupla.sort() #No se pueden ordenar diferentes tipos de datos
# print(tupla)

ciudades={'Madrid','Sevilla','Barcelona','Badajoz','Segovia'} #Los resultados no se pueden ordenar al ser un set.
#ciudades.sort()
#print(ciudades)

dias={'Lunes' : 7,'Martes' : 8.5,'Miércoles' : 6,'Jueves' : 7,'Viernes' : 9}
print(dias)
contador=0
for d in dias.values():
    contador=contador+d
print(contador)
print(contador/len(dias))