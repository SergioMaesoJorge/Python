class Curso:
    def __init__(self,id,nombre, creditos, tiempoDeEstudio):
        self.id=id
        self.nombre=nombre
        self.creditos=creditos
        self.tiempoDeEstudio=tiempoDeEstudio


class Alumno:
    def __init__(self,id,nombre,email):
        self.id=id
        self.nombre=nombre
        self.email=email


class Matricula:
    def __init__(self,idMatricula,fechaMatricula,idAlumno,idCurso):
        self.idMatricula=idMatricula
        self.fechaMatricula=fechaMatricula
        self.idAlumno=idAlumno
        self.idCurso=idCurso

curso1=Curso(1,'DAW',12,2)
curso2=Curso(2,'DAM',12,2)
curso3=Curso(3,'Doble grado',18,3)
alumno1=Alumno(1,'Juan','Juan@gmail.com')
alumno2=Alumno(2,'Antonio','Antonio@gmail.com')
alumno3=Alumno(3,'Pepe','Pepe@gmail.com')

cursos=[curso1,curso2,curso3]
alumnos=[alumno1,alumno2,alumno3]

for c in cursos:
    print(c.id,c.nombre,c.creditos,c.tiempoDeEstudio)

for a in alumnos:
    print(a.id,a.nombre,a.email)